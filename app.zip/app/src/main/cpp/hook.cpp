// Redirects reads of "*.material.bin" assets to replacement files on disk.
// Hooks libandroid.so's AAsset* functions, so no per-version offsets are needed.
// UNTESTED: Minecraft may also read assets via other paths.
#include <jni.h>
#include <android/asset_manager.h>
#include <android/log.h>
#include <shadowhook.h>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iterator>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#define TAG "ShaderHook"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct Override { std::vector<uint8_t> data; size_t pos = 0; };

static std::mutex g_mu;
static std::unordered_map<AAsset*, Override> g_over;
static std::string g_dir;

static AAsset* (*o_open)(AAssetManager*, const char*, int);
static void    (*o_close)(AAsset*);
static int     (*o_read)(AAsset*, void*, size_t);
static off_t   (*o_len)(AAsset*);
static off64_t (*o_len64)(AAsset*);
static off_t   (*o_rem)(AAsset*);
static off64_t (*o_rem64)(AAsset*);
static off_t   (*o_seek)(AAsset*, off_t, int);
static off64_t (*o_seek64)(AAsset*, off64_t, int);
static const void* (*o_buf)(AAsset*);

static Override* find(AAsset* a) {
    std::lock_guard<std::mutex> l(g_mu);
    auto it = g_over.find(a);
    return it == g_over.end() ? nullptr : &it->second;
}

static bool endsWith(const std::string& s, const char* suf) {
    size_t n = strlen(suf);
    return s.size() >= n && s.compare(s.size() - n, n, suf) == 0;
}

static AAsset* h_open(AAssetManager* m, const char* name, int mode) {
    AAsset* a = o_open(m, name, mode);  // real handle keeps lifetime semantics
    if (!a || !name) return a;
    std::string path(name);
    if (!endsWith(path, ".material.bin")) return a;

    std::string base = path.substr(path.find_last_of('/') + 1);
    std::ifstream f(g_dir + "/" + base, std::ios::binary);
    if (!f) return a;

    Override o;
    o.data.assign(std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>());
    {
        std::lock_guard<std::mutex> l(g_mu);
        g_over[a] = std::move(o);
    }
    LOGI("override %s", base.c_str());
    return a;
}

static void h_close(AAsset* a) {
    { std::lock_guard<std::mutex> l(g_mu); g_over.erase(a); }
    o_close(a);
}

static int h_read(AAsset* a, void* buf, size_t n) {
    Override* o = find(a);
    if (!o) return o_read(a, buf, n);
    size_t left = o->data.size() - o->pos;
    size_t c = n < left ? n : left;
    memcpy(buf, o->data.data() + o->pos, c);
    o->pos += c;
    return (int)c;
}

static off_t h_len(AAsset* a)     { Override* o = find(a); return o ? (off_t)o->data.size() : o_len(a); }
static off64_t h_len64(AAsset* a) { Override* o = find(a); return o ? (off64_t)o->data.size() : o_len64(a); }
static off_t h_rem(AAsset* a)     { Override* o = find(a); return o ? (off_t)(o->data.size() - o->pos) : o_rem(a); }
static off64_t h_rem64(AAsset* a) { Override* o = find(a); return o ? (off64_t)(o->data.size() - o->pos) : o_rem64(a); }
static const void* h_buf(AAsset* a) { Override* o = find(a); return o ? o->data.data() : o_buf(a); }

static int64_t doSeek(Override* o, int64_t off, int whence) {
    int64_t base = whence == SEEK_SET ? 0 : whence == SEEK_CUR ? (int64_t)o->pos : (int64_t)o->data.size();
    int64_t np = base + off;
    if (np < 0 || np > (int64_t)o->data.size()) return -1;
    o->pos = (size_t)np;
    return np;
}
static off_t h_seek(AAsset* a, off_t off, int w)        { Override* o = find(a); return o ? (off_t)doSeek(o, off, w) : o_seek(a, off, w); }
static off64_t h_seek64(AAsset* a, off64_t off, int w)  { Override* o = find(a); return o ? (off64_t)doSeek(o, off, w) : o_seek64(a, off, w); }

static bool hook(const char* sym, void* fn, void** orig) {
    void* stub = shadowhook_hook_sym_name("libandroid.so", sym, fn, orig);
    if (!stub) LOGE("hook failed: %s", sym);
    return stub != nullptr;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_mcshaderlauncher_NativeHook_init(JNIEnv* env, jclass, jstring dir) {
    const char* d = env->GetStringUTFChars(dir, nullptr);
    g_dir = d;
    env->ReleaseStringUTFChars(dir, d);

    if (shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false) != 0) return JNI_FALSE;

    bool ok = true;
    ok &= hook("AAssetManager_open",        (void*)h_open,  (void**)&o_open);
    ok &= hook("AAsset_close",              (void*)h_close, (void**)&o_close);
    ok &= hook("AAsset_read",               (void*)h_read,  (void**)&o_read);
    ok &= hook("AAsset_getLength",          (void*)h_len,   (void**)&o_len);
    ok &= hook("AAsset_getLength64",        (void*)h_len64, (void**)&o_len64);
    ok &= hook("AAsset_getRemainingLength", (void*)h_rem,   (void**)&o_rem);
    ok &= hook("AAsset_getRemainingLength64",(void*)h_rem64,(void**)&o_rem64);
    ok &= hook("AAsset_seek",               (void*)h_seek,  (void**)&o_seek);
    ok &= hook("AAsset_seek64",             (void*)h_seek64,(void**)&o_seek64);
    ok &= hook("AAsset_getBuffer",          (void*)h_buf,   (void**)&o_buf);
    LOGI("hooks installed: %d, dir=%s", ok, g_dir.c_str());
    return ok ? JNI_TRUE : JNI_FALSE;
}
