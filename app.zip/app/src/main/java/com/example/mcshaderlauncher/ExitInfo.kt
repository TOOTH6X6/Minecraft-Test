package com.example.mcshaderlauncher

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build

/** Reads why this app's previous process died (Android 11+), incl. native crash details. */
object ExitInfo {
    fun read(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 30) return "(ต้อง Android 11 ขึ้นไป)"
        return try {
            val am = ctx.getSystemService(ActivityManager::class.java)
            val list = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 2)
            if (list.isEmpty()) return "(ไม่มี)"
            list.joinToString("\n\n") { e ->
                "reason=${name(e.reason)} status=${e.status}\n${e.description ?: ""}\n${traceStrings(e)}"
            }
        } catch (t: Throwable) {
            "error: $t"
        }
    }

    private fun name(r: Int) = when (r) {
        ApplicationExitInfo.REASON_CRASH -> "CRASH(java)"
        ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE"
        ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED"
        ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
        ApplicationExitInfo.REASON_ANR -> "ANR"
        ApplicationExitInfo.REASON_USER_REQUESTED -> "USER_REQUESTED"
        else -> r.toString()
    }

    /** Pulls readable lines (abort message, signal, .so names) out of the tombstone. */
    private fun traceStrings(e: ApplicationExitInfo): String {
        val ins = try { e.traceInputStream } catch (t: Throwable) { null } ?: return ""
        val data = ins.use { it.readBytes() }
        val out = LinkedHashSet<String>()
        val cur = StringBuilder()
        fun flush() {
            if (cur.length >= 8) {
                val s = cur.toString()
                if (s.contains(".so") || s.contains("Abort") || s.contains("SIG") ||
                    s.contains("JNI") || s.contains("FATAL") || s.contains("pairip", true)
                ) out.add(s.take(160))
            }
            cur.setLength(0)
        }
        for (b in data.take(600_000)) {
            val c = b.toInt() and 0xff
            if (c in 32..126) cur.append(c.toChar()) else flush()
        }
        flush()
        return out.take(40).joinToString("\n")
    }
}
