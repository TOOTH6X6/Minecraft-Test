package com.example.mcshaderlauncher

import android.app.Application
import android.content.Context

class LauncherApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        McBridge.prepare(base)
    }
}
