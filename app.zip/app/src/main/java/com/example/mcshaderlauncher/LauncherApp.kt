package com.example.mcshaderlauncher

import android.app.Application
import android.content.Context
import android.util.Log

class LauncherApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        DebugLog.init(base)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            DebugLog.log("CRASH in thread ${t.name}:\n" + Log.getStackTraceString(e).take(3000))
            prev?.uncaughtException(t, e)
        }
        McBridge.prepare(base)
    }
}
