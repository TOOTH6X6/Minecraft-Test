package com.example.mcshaderlauncher

import android.content.Context
import android.os.Build
import dalvik.system.BaseDexClassLoader
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.io.File
import java.util.zip.ZipFile

/**
 * Makes the installed Minecraft's code and native libs visible to THIS app's class loader,
 * so LauncherActivity can extend the real com.mojang.minecraftpe.MainActivity.
 * Must run before any native library is loaded (called from LauncherApp).
 */
object McBridge {
    const val PKG = "com.mojang.minecraftpe"
    @Volatile var error: String? = null
    @Volatile var report: String = ""

    fun prepare(ctx: Context) {
        val r = StringBuilder()
        try {
            r.appendLine("SDK=${Build.VERSION.SDK_INT} abis=${Build.SUPPORTED_ABIS.joinToString()}")
            val info = ctx.packageManager.getApplicationInfo(PKG, 0)
            r.appendLine("mc source=${info.sourceDir}")
            r.appendLine("mc splits=${info.splitSourceDirs?.size ?: 0}")
            r.appendLine("mc nativeDir=${info.nativeLibraryDir}")
            if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("L")

            val cl = ctx.classLoader
            val base = BaseDexClassLoader::class.java
            val apks = listOf(info.sourceDir) + (info.splitSourceDirs?.toList() ?: emptyList())

            val abi = Build.SUPPORTED_64_BIT_ABIS.firstOrNull() ?: Build.SUPPORTED_ABIS[0]
            r.appendLine("abi=$abi")
            r.appendLine("libminecraftpe in nativeDir: " +
                File(info.nativeLibraryDir ?: "", "libminecraftpe.so").exists())
            apks.forEach { a ->
                val has = try {
                    ZipFile(a).use { it.getEntry("lib/$abi/libminecraftpe.so") != null }
                } catch (e: Exception) { false }
                r.appendLine("apk ${File(a).name}: has lib=$has")
            }

            val nativePaths = ArrayList<String>()
            info.nativeLibraryDir?.let { nativePaths.add(it) }
            apks.forEach { nativePaths.add("$it!/lib/$abi") }

            val dexPaths = apks.joinToString(File.pathSeparator)
            try {
                base.getDeclaredMethod("addDexPath", String::class.java)
                    .apply { isAccessible = true }.invoke(cl, dexPaths)
            } catch (e: NoSuchMethodException) {
                base.getDeclaredMethod("addDexPath", String::class.java, Boolean::class.javaPrimitiveType)
                    .apply { isAccessible = true }.invoke(cl, dexPaths, true)
            }
            base.getDeclaredMethod("addNativePath", Collection::class.java)
                .apply { isAccessible = true }.invoke(cl, nativePaths)
            r.appendLine("paths added")

            try {
                Class.forName("com.mojang.minecraftpe.MainActivity", false, cl)
                r.appendLine("MainActivity class: OK")
            } catch (t: Throwable) {
                r.appendLine("MainActivity class: FAIL $t")
                error = "หาคลาส MainActivity ของเกมไม่เจอ"
            }
        } catch (t: Throwable) {
            error = t.toString().take(200)
            r.appendLine("prepare error: $t")
        }
        report = r.toString()
    }

    /**
     * The linker namespace of this app was created before we added Minecraft's lib dir,
     * so DT_NEEDED libs (fmod, pairipcore, ...) are not found. Loading each lib by absolute
     * path first lets the linker match them by soname when libminecraftpe.so is loaded.
     */
    fun preloadNative(ctx: Context): String {
        val sb = StringBuilder()
        try {
            val info = ctx.packageManager.getApplicationInfo(PKG, 0)
            val dir = File(info.nativeLibraryDir ?: return "no nativeLibraryDir")
            val all = dir.listFiles()?.map { it.name } ?: emptyList()
            sb.appendLine("libs in dir: ${all.joinToString()}")
            var pending = dir.listFiles { f -> f.name.endsWith(".so") && f.name != "libminecraftpe.so" }
                ?.sortedBy { it.name }?.toList() ?: emptyList()
            val lastErr = HashMap<String, String>()
            var progress = true
            while (pending.isNotEmpty() && progress) {
                progress = false
                val next = ArrayList<File>()
                for (f in pending) {
                    DebugLog.log("preload: loading ${f.name}")
                    try {
                        System.load(f.absolutePath)
                        sb.appendLine("loaded ${f.name}")
                        progress = true
                    } catch (t: UnsatisfiedLinkError) {
                        lastErr[f.name] = t.message?.take(160) ?: "?"
                        next.add(f)
                    }
                }
                pending = next
            }
            pending.forEach { sb.appendLine("FAILED ${it.name}: ${lastErr[it.name]}") }
        } catch (t: Throwable) {
            sb.appendLine("preload error: $t")
        }
        return sb.toString()
    }
}
