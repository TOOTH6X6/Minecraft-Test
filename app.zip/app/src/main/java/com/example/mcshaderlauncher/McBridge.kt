package com.example.mcshaderlauncher

import android.content.Context
import android.os.Build
import dalvik.system.BaseDexClassLoader
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.io.File

/**
 * Makes the installed Minecraft's code and native libs visible to THIS app's class loader,
 * so LauncherActivity can extend the real com.mojang.minecraftpe.MainActivity.
 * Must run before any native library is loaded (called from LauncherApp).
 */
object McBridge {
    const val PKG = "com.mojang.minecraftpe"
    @Volatile var error: String? = null

    fun prepare(ctx: Context) {
        try {
            val info = ctx.packageManager.getApplicationInfo(PKG, 0)
            if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("L")

            val cl = ctx.classLoader
            val base = BaseDexClassLoader::class.java
            val apks = listOf(info.sourceDir) + (info.splitSourceDirs?.toList() ?: emptyList())

            val abi = Build.SUPPORTED_64_BIT_ABIS.firstOrNull() ?: Build.SUPPORTED_ABIS[0]
            val nativePaths = ArrayList<String>()
            info.nativeLibraryDir?.let { nativePaths.add(it) }
            apks.forEach { nativePaths.add("$it!/lib/$abi") }

            val dexPaths = apks.joinToString(File.pathSeparator)
            try {
                base.getDeclaredMethod("addDexPath", String::class.java)
                    .apply { isAccessible = true }.invoke(cl, dexPaths)
            } catch (e: NoSuchMethodException) {
                base.getDeclaredMethod("addDexPath", String::class.java, Boolean::class.javaPrimitiveType)
                    .apply { isAccessible = true }.invoke(cl, dexPaths, true)
            }
            base.getDeclaredMethod("addNativePath", Collection::class.java)
                .apply { isAccessible = true }.invoke(cl, nativePaths)
        } catch (t: Throwable) {
            error = t.toString().take(200)
        }
    }
}
