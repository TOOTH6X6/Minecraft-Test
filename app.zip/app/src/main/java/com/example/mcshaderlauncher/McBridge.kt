package com.example.mcshaderlauncher

import android.content.Context
import android.os.Build
import dalvik.system.BaseDexClassLoader
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipFile

/**
 * Makes the installed Minecraft's code and native libs visible to THIS app's class loader,
 * so LauncherActivity can extend the real com.mojang.minecraftpe.MainActivity.
 * Must run before any native library is loaded (called from LauncherApp).
 */
object McBridge {
    const val PKG = "com.mojang.minecraftpe"
    @Volatile var error: String? = null
    @Volatile var report: String = ""

    fun prepare(ctx: Context) {
        val r = StringBuilder()
        try {
            r.appendLine("SDK=${Build.VERSION.SDK_INT} abis=${Build.SUPPORTED_ABIS.joinToString()}")
            val info = ctx.packageManager.getApplicationInfo(PKG, 0)
            r.appendLine("mc source=${info.sourceDir}")
            r.appendLine("mc splits=${info.splitSourceDirs?.size ?: 0}")
            r.appendLine("mc nativeDir=${info.nativeLibraryDir}")
            if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("L")

            val cl = ctx.classLoader
            val base = BaseDexClassLoader::class.java
            val apks = listOf(info.sourceDir) + (info.splitSourceDirs?.toList() ?: emptyList())

            val abi = Build.SUPPORTED_64_BIT_ABIS.firstOrNull() ?: Build.SUPPORTED_ABIS[0]
            r.appendLine("abi=$abi")
            r.appendLine("libminecraftpe in nativeDir: " +
                File(info.nativeLibraryDir ?: "", "libminecraftpe.so").exists())
            apks.forEach { a ->
                val has = try {
                    ZipFile(a).use { it.getEntry("lib/$abi/libminecraftpe.so") != null }
                } catch (e: Exception) { false }
                r.appendLine("apk ${File(a).name}: has lib=$has")
            }

            val nativePaths = ArrayList<String>()
            info.nativeLibraryDir?.let { nativePaths.add(it) }
            apks.forEach { nativePaths.add("$it!/lib/$abi") }

            val dexPaths = apks.joinToString(File.pathSeparator)
            try {
                base.getDeclaredMethod("addDexPath", String::class.java)
                    .apply { isAccessible = true }.invoke(cl, dexPaths)
            } catch (e: NoSuchMethodException) {
                base.getDeclaredMethod("addDexPath", String::class.java, Boolean::class.javaPrimitiveType)
                    .apply { isAccessible = true }.invoke(cl, dexPaths, true)
            }
            base.getDeclaredMethod("addNativePath", Collection::class.java)
                .apply { isAccessible = true }.invoke(cl, nativePaths)
            r.appendLine("paths added")

            try {
                Class.forName("com.mojang.minecraftpe.MainActivity", false, cl)
                r.appendLine("MainActivity class: OK")
            } catch (t: Throwable) {
                r.appendLine("MainActivity class: FAIL $t")
                error = "หาคลาส MainActivity ของเกมไม่เจอ"
            }
        } catch (t: Throwable) {
            error = t.toString().take(200)
            r.appendLine("prepare error: $t")
        }
        report = r.toString()
    }

    /** Reads DT_NEEDED entries from a 64-bit little-endian ELF file. */
    private fun neededLibs(f: File): List<String> {
        RandomAccessFile(f, "r").use { raf ->
            fun buf(pos: Long, n: Int): ByteBuffer {
                val b = ByteArray(n)
                raf.seek(pos); raf.readFully(b)
                return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
            }
            class Seg(val type: Int, val off: Long, val vaddr: Long, val filesz: Long)

            val h = buf(0, 64)
            val phoff = h.getLong(0x20)
            val phentsize = h.getShort(0x36).toInt() and 0xffff
            val phnum = h.getShort(0x38).toInt() and 0xffff
            val segs = (0 until phnum).map { i ->
                val p = buf(phoff + i.toLong() * phentsize, 56)
                Seg(p.getInt(0), p.getLong(8), p.getLong(16), p.getLong(32))
            }
            val loads = segs.filter { it.type == 1 }
            fun v2o(v: Long): Long {
                val s = loads.first { v >= it.vaddr && v < it.vaddr + it.filesz }
                return s.off + (v - s.vaddr)
            }
            val dyn = segs.first { it.type == 2 }
            val d = buf(dyn.off, dyn.filesz.toInt())
            val needed = ArrayList<Long>()
            var strtab = 0L
            var i = 0
            while (i + 16 <= d.capacity()) {
                val tag = d.getLong(i)
                val v = d.getLong(i + 8)
                if (tag == 0L) break
                if (tag == 1L) needed.add(v)
                if (tag == 5L) strtab = v
                i += 16
            }
            val stroff = v2o(strtab)
            return needed.map { n ->
                raf.seek(stroff + n)
                val sb = StringBuilder()
                while (true) {
                    val c = raf.read()
                    if (c <= 0) break
                    sb.append(c.toChar())
                }
                sb.toString()
            }
        }
    }

    /**
     * The linker namespace of this app was created before we added Minecraft's lib dir,
     * so libs that libminecraftpe.so depends on are not found. We read its DT_NEEDED list and
     * load those libs (dependencies first) by absolute path, so the linker can match them by soname.
     */
    fun preloadNative(ctx: Context): String {
        val sb = StringBuilder()
        try {
            val info = ctx.packageManager.getApplicationInfo(PKG, 0)
            val dir = File(info.nativeLibraryDir ?: return "no nativeLibraryDir")
            sb.appendLine("libs in dir: ${dir.listFiles()?.map { it.name }?.sorted()?.joinToString()}")
            val main = File(dir, "libminecraftpe.so")
            val needed = neededLibs(main)
            sb.appendLine("libminecraftpe needs: ${needed.joinToString()}")

            val seen = HashSet<String>()
            fun load(name: String) {
                if (!seen.add(name)) return
                val f = File(dir, name)
                if (!f.exists()) return          // system lib, linker finds it
                neededLibs(f).forEach { load(it) }
                DebugLog.log("preload: loading $name")
                try {
                    System.load(f.absolutePath)
                    DebugLog.log("preload: ok $name")
                } catch (t: UnsatisfiedLinkError) {
                    DebugLog.log("preload: FAIL $name ${t.message?.take(200)}")
                }
            }
            needed.forEach { load(it) }
        } catch (t: Throwable) {
            sb.appendLine("preload error: $t")
        }
        return sb.toString()
    }
}
