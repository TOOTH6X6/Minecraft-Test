package com.example.mcshaderlauncher

object NativeHook {
    init { System.loadLibrary("shaderhook") }

    /** Installs asset hooks. dir = folder holding replacement *.material.bin files. */
    external fun init(dir: String): Boolean
}
