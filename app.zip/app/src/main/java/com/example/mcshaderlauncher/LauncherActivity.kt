package com.example.mcshaderlauncher

import android.content.Context
import android.content.res.AssetManager
import android.os.Bundle
import com.mojang.minecraftpe.MainActivity as McMainActivity

/**
 * Compile time: extends a stub. Runtime: extends the REAL Minecraft MainActivity,
 * which McBridge made loadable from the installed game's APKs.
 */
class LauncherActivity : McMainActivity() {

    private val mcCtx: Context? by lazy {
        try { createPackageContext(McBridge.PKG, 0) } catch (e: Exception) { null }
    }

    // The native game reads assets (incl. renderer/materials) through this AssetManager.
    override fun getAssets(): AssetManager = mcCtx?.assets ?: super.getAssets()

    override fun onCreate(savedInstanceState: Bundle?) {
        // Hooks must be in place before the game starts reading assets.
        runCatching { NativeHook.init(PackStore(this).activeDir.absolutePath) }
        super.onCreate(savedInstanceState)
    }
}
