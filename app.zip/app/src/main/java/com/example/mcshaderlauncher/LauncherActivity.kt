package com.example.mcshaderlauncher

import android.content.Context
import android.content.res.AssetManager
import android.os.Bundle
import com.mojang.minecraftpe.MainActivity as McMainActivity

/**
 * Compile time: extends a stub. Runtime: extends the REAL Minecraft MainActivity,
 * which McBridge made loadable from the installed game's APKs.
 */
class LauncherActivity : McMainActivity() {

    private val mcCtx: Context? by lazy {
        try { createPackageContext(McBridge.PKG, 0) } catch (e: Exception) { null }
    }

    // The native game reads assets (incl. renderer/materials) through this AssetManager.
    override fun getAssets(): AssetManager = mcCtx?.assets ?: super.getAssets()

    override fun onCreate(savedInstanceState: Bundle?) {
        DebugLog.log("LauncherActivity.onCreate start; super class=${javaClass.superclass?.name}")
        DebugLog.log("mc context: ${if (mcCtx != null) "ok" else "NULL"}")
        // Hooks must be in place before the game starts reading assets.
        try {
            val ok = NativeHook.init(PackStore(this).activeDir.absolutePath)
            DebugLog.log("NativeHook.init -> $ok")
        } catch (t: Throwable) {
            DebugLog.log("NativeHook.init FAILED: $t")
        }
        DebugLog.log("calling super.onCreate (if log stops here = native crash)")
        try {
            super.onCreate(savedInstanceState)
        } catch (t: Throwable) {
            DebugLog.log("super.onCreate threw: $t")
            throw t
        }
        DebugLog.log("super.onCreate returned")
    }
}
