package com.example.mcshaderlauncher

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/** Keeps imported shader packs and tracks which one is active. */
class PackStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("packs", Context.MODE_PRIVATE)

    val bedrockDir = File(ctx.filesDir, "packs/bedrock").apply { mkdirs() }
    val javaDir = File(ctx.filesDir, "packs/java").apply { mkdirs() }
    /** Folder the native hook reads *.material.bin from. */
    val activeDir = File(ctx.filesDir, "shaders/active").apply { mkdirs() }

    var activeBedrock: String?
        get() = prefs.getString("bedrock", null)
        set(v) { prefs.edit().putString("bedrock", v).apply() }

    var activeJava: String?
        get() = prefs.getString("java", null)
        set(v) { prefs.edit().putString("java", v).apply() }

    var javaTarget: Uri?
        get() = prefs.getString("java_target", null)?.let { Uri.parse(it) }
        set(v) { prefs.edit().putString("java_target", v?.toString()).apply() }

    fun bedrockPacks(): List<String> =
        bedrockDir.listFiles { f -> f.isDirectory }?.map { it.name }?.sorted() ?: emptyList()

    fun javaPacks(): List<String> =
        javaDir.listFiles { f -> f.isFile && f.name.endsWith(".zip", true) }
            ?.map { it.name }?.sorted() ?: emptyList()

    private fun copy(from: Uri, to: File) {
        ctx.contentResolver.openInputStream(from)?.use { i ->
            to.outputStream().use { i.copyTo(it) }
        }
    }

    /** Import a folder of *.material.bin (or a folder that contains "materials/"). Returns file count. */
    fun importBedrock(tree: Uri): Int {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return 0
        val src = root.listFiles().firstOrNull { it.isDirectory && it.name == "materials" } ?: root
        val files = src.listFiles().filter { it.isFile && it.name?.endsWith(".material.bin") == true }
        if (files.isEmpty()) return 0
        var name = (root.name ?: "pack").replace('/', '_')
        if (name == "materials") name = "pack_" + (System.currentTimeMillis() % 100000)
        val dest = File(bedrockDir, name).apply { deleteRecursively(); mkdirs() }
        files.forEach { copy(it.uri, File(dest, it.name!!)) }
        return files.size
    }

    /** Import Java shaderpack zips. Returns how many were imported. */
    fun importJava(uris: List<Uri>): Int {
        var n = 0
        for (u in uris) {
            val name = DocumentFile.fromSingleUri(ctx, u)?.name ?: continue
            if (!name.endsWith(".zip", true)) continue
            copy(u, File(javaDir, name))
            n++
        }
        return n
    }

    /** name == null turns Bedrock shaders off. */
    fun applyBedrock(name: String?): Boolean {
        activeDir.listFiles()?.forEach { it.delete() }
        if (name != null) {
            val files = File(bedrockDir, name).listFiles() ?: return false
            files.forEach { it.copyTo(File(activeDir, it.name), true) }
        }
        activeBedrock = name
        return true
    }

    /**
     * Installs the zip into the Java launcher's shaderpacks folder (picked by the user).
     * name == null removes the one installed earlier. Returns an error message or null.
     */
    fun applyJava(name: String?): String? {
        val target = javaTarget ?: return "ยังไม่ได้ตั้งโฟลเดอร์ shaderpacks ของ Java"
        val dir = DocumentFile.fromTreeUri(ctx, target) ?: return "เข้าโฟลเดอร์ปลายทางไม่ได้"
        activeJava?.let { dir.findFile(it)?.delete() }
        if (name != null) {
            dir.findFile(name)?.delete()
            val out = dir.createFile("application/zip", name) ?: return "สร้างไฟล์ปลายทางไม่ได้"
            val ok = ctx.contentResolver.openOutputStream(out.uri)?.use { o ->
                File(javaDir, name).inputStream().use { it.copyTo(o) }
                true
            } ?: false
            if (!ok) return "เขียนไฟล์ไม่ได้"
            activeJava = out.name
        } else {
            activeJava = null
        }
        return null
    }
}
