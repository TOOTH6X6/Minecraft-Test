package com.example.mcshaderlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ServiceCompat
import kotlin.math.abs

private class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** Floating draggable bubble; tap it to open a menu for switching shader packs. */
class OverlayService : Service() {
    companion object { @Volatile var running = false }

    private lateinit var wm: WindowManager
    private lateinit var store: PackStore
    private val ui = Handler(Looper.getMainLooper())
    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        startForegroundNotif()   // must come first, before any early stopSelf()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = PackStore(this)
        addBubble()
        running = true
    }

    override fun onDestroy() {
        running = false
        if (::wm.isInitialized) {
            hidePanel()
            bubble?.let { runCatching { wm.removeView(it) } }
        }
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun startForegroundNotif() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("overlay", "Floating menu", NotificationManager.IMPORTANCE_LOW)
        )
        val tap = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("MC Shader Launcher")
            .setContentText("ปุ่มลอยกำลังทำงาน")
            .setContentIntent(tap)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    private fun addBubble() {
        val v = TextView(this).apply {
            text = "S"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC2E7D32.toInt())
            }
        }
        val lp = params(dp(52), dp(52)).apply { x = dp(8); y = dp(200) }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false

        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                        if (!moved) hidePanel()
                        moved = true
                    }
                    if (moved) {
                        lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (panel != null) hidePanel() else showPanel() }
            }
            true
        }
        bubble = v; bubbleLp = lp
        wm.addView(v, lp)
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    private fun showPanel() {
        hidePanel()
        val b = bubbleLp ?: return
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val w = dp(250)
        val view = buildPanel((sh * 0.6f).toInt())
        val lp = params(w, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = b.x.coerceIn(dp(8), maxOf(dp(8), sw - w - dp(8)))
            y = (b.y + dp(58)).coerceIn(dp(8), maxOf(dp(8), sh - dp(420)))
        }
        wm.addView(view, lp)
        panel = view
    }

    private fun buildPanel(maxH: Int): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        fun header(t: String) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(0xFFA5D6A7.toInt())
            setPadding(0, dp(8), 0, dp(2))
        }
        fun item(label: String, marker: String, onClick: () -> Unit) = TextView(this).apply {
            text = "$marker$label"; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(6), dp(9), dp(6), dp(9))
            setOnClickListener { onClick() }
        }
        fun mark(on: Boolean) = if (on) "● " else "○ "

        col.addView(header("Bedrock (.material.bin)"))
        col.addView(item("ปิดชเดอร์", mark(store.activeBedrock == null)) { applyBedrock(null) })
        store.bedrockPacks().forEach { n ->
            col.addView(item(n, mark(store.activeBedrock == n)) { applyBedrock(n) })
        }
        col.addView(header("Java (shaderpacks .zip)"))
        col.addView(item("ถอนชเดอร์", mark(store.activeJava == null)) { applyJava(null) })
        store.javaPacks().forEach { n ->
            col.addView(item(n, mark(store.activeJava == n)) { applyJava(n) })
        }
        col.addView(header(""))
        col.addView(item("ย่อเมนู", "") { hidePanel() })
        col.addView(item("ปิดปุ่มลอย", "") { stopSelf() })

        return MaxHeightScroll(this, maxH).apply {
            background = GradientDrawable().apply {
                setColor(0xEE212121.toInt()); cornerRadius = dp(12).toFloat()
            }
            addView(col)
        }
    }

    private fun applyBedrock(name: String?) {
        Thread {
            val ok = store.applyBedrock(name)
            ui.post {
                toast(if (!ok) "ใช้ pack ไม่สำเร็จ" else "Bedrock: ${name ?: "ปิด"} (รีสตาร์ทเกมเพื่อให้มีผล)")
                if (panel != null) showPanel()
            }
        }.start()
    }

    private fun applyJava(name: String?) {
        Thread {
            val err = store.applyJava(name)
            ui.post {
                toast(err ?: "Java: ${name ?: "ถอนแล้ว"} (เลือกในเกมอีกที)")
                if (panel != null) showPanel()
            }
        }.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
