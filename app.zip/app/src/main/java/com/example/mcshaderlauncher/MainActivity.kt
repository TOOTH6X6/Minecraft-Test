package com.example.mcshaderlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import java.io.File
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val mcPackage = "com.mojang.minecraftpe"
    private val rcBedrock = 1001
    private val rcJava = 1002
    private val rcTarget = 1003
    private lateinit var status: TextView
    private lateinit var store: PackStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = PackStore(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val pad = (16 * resources.displayMetrics.density).toInt()
        status = TextView(this).apply { textSize = 15f }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(status)
            addView(btn("1) อนุญาตแสดงทับแอปอื่น (Overlay)") {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            })
            addView(btn("2) เปิด / ปิด ปุ่มลอย") { toggleOverlay() })
            addView(btn("นำเข้า Bedrock pack (โฟลเดอร์ .material.bin)") {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), rcBedrock)
            })
            addView(btn("นำเข้า Java shaderpack (.zip)") {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("*/*")
                        .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true),
                    rcJava
                )
            })
            addView(btn("ตั้งโฟลเดอร์ shaderpacks ของลอนเชอร์ Java") {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    ),
                    rcTarget
                )
            })
            addView(btn("เปิด Minecraft + ชเดอร์ (ทดลอง)") { launchModded() })
            addView(btn("เปิด Minecraft ปกติ") { launchGame() })
            addView(btn("ดู log ของ hook") { showHookLog() })
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun btn(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun refresh() {
        val ver = try {
            packageManager.getPackageInfo(mcPackage, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) { null }
        status.text = "Minecraft: ${ver ?: "ไม่พบ (ต้องติดตั้งเกมแท้ก่อน)"}\n" +
            "Overlay: ${if (Settings.canDrawOverlays(this)) "อนุญาตแล้ว" else "ยังไม่อนุญาต"}" +
            " / ปุ่มลอย: ${if (OverlayService.running) "เปิดอยู่" else "ปิด"}\n" +
            "Bedrock packs: ${store.bedrockPacks().size} (ใช้อยู่: ${store.activeBedrock ?: "-"})\n" +
            "Java packs: ${store.javaPacks().size} (ติดตั้งอยู่: ${store.activeJava ?: "-"})\n" +
            "โฟลเดอร์ Java: ${store.javaTarget?.lastPathSegment ?: "ยังไม่ตั้ง"}\n" +
            "เตรียมโหลดเกม: ${McBridge.error ?: "พร้อม"}"
    }

    private fun toggleOverlay() {
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) {
            stopService(i)
        } else if (!Settings.canDrawOverlays(this)) {
            toast("กดข้อ 1 อนุญาต Overlay ก่อน")
        } else {
            startForegroundService(i)
        }
        window.decorView.postDelayed({ refresh() }, 500)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            rcBedrock -> {
                val uri = data.data ?: return
                Thread {
                    val n = store.importBedrock(uri)
                    runOnUiThread {
                        toast(if (n == 0) "ไม่พบไฟล์ .material.bin" else "นำเข้า $n ไฟล์แล้ว")
                        refresh()
                    }
                }.start()
            }
            rcJava -> {
                val uris = mutableListOf<Uri>()
                data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
                data.data?.let { uris.add(it) }
                Thread {
                    val n = store.importJava(uris)
                    runOnUiThread {
                        toast(if (n == 0) "ไม่พบไฟล์ .zip" else "นำเข้า $n แพ็คแล้ว")
                        refresh()
                    }
                }.start()
            }
            rcTarget -> {
                val uri = data.data ?: return
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                store.javaTarget = uri
                refresh()
            }
        }
    }

    private fun launchGame() {
        val intent = packageManager.getLaunchIntentForPackage(mcPackage)
        if (intent == null) { toast("ไม่พบ Minecraft"); return }
        startActivity(intent)
    }

    private fun launchModded() {
        if (packageManager.getLaunchIntentForPackage(mcPackage) == null) {
            toast("ไม่พบ Minecraft"); return
        }
        McBridge.error?.let { toast("เตรียมโหลดเกมไม่สำเร็จ: $it"); return }
        startActivity(Intent(this, LauncherActivity::class.java))
    }

    private fun showHookLog() {
        val f = File(filesDir, "shaders/hook.log")
        val text = if (f.exists()) f.readLines().takeLast(25).joinToString("\n")
        else "ยังไม่มี log (ยังไม่เคยเปิดเกมแบบมีชเดอร์)"
        AlertDialog.Builder(this).setTitle("hook log")
            .setMessage(text).setPositiveButton("ปิด", null).show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
