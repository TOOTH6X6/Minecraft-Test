package com.example.mcshaderlauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import java.io.File

class MainActivity : Activity() {
    private val mcPackage = "com.mojang.minecraftpe"
    private val reqPick = 1001
    private lateinit var status: TextView
    private val activeDir by lazy { File(filesDir, "shaders/active").apply { mkdirs() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        status = TextView(this).apply { textSize = 16f }
        val pick = Button(this).apply {
            text = "เลือกโฟลเดอร์ Shader Pack (.material.bin)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), reqPick)
            }
        }
        val launch = Button(this).apply {
            text = "เปิด Minecraft"
            setOnClickListener { launchGame() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(status); addView(pick); addView(launch)
        })
        refresh()
    }

    private fun refresh() {
        val ver = try {
            packageManager.getPackageInfo(mcPackage, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) { null }
        val count = activeDir.listFiles { f -> f.name.endsWith(".material.bin") }?.size ?: 0
        status.text = "Minecraft: ${ver ?: "ไม่พบ (ต้องติดตั้งเกมแท้ก่อน)"}\n" +
                "ไฟล์ material ที่เลือกไว้: $count"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        Thread {
            activeDir.listFiles()?.forEach { it.delete() }
            val tree = DocumentFile.fromTreeUri(this, uri)
            tree?.listFiles()?.filter { it.name?.endsWith(".material.bin") == true }?.forEach { doc ->
                contentResolver.openInputStream(doc.uri)?.use { input ->
                    File(activeDir, doc.name!!).outputStream().use { input.copyTo(it) }
                }
            }
            runOnUiThread { refresh() }
        }.start()
    }

    private fun launchGame() {
        val intent = packageManager.getLaunchIntentForPackage(mcPackage)
        if (intent == null) {
            Toast.makeText(this, "ไม่พบ Minecraft", Toast.LENGTH_SHORT).show()
            return
        }
        // TODO (Stage 2): load Minecraft in THIS process, then call
        // NativeHook.init(activeDir.absolutePath) so the hooks take effect.
        // For now this only starts the stock game.
        Toast.makeText(this, "Stage 2 ยังไม่ทำ: เปิดเกมแบบปกติ", Toast.LENGTH_LONG).show()
        startActivity(intent)
    }
}
