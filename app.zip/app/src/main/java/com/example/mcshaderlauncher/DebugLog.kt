package com.example.mcshaderlauncher

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tiny file logger so crashes can be read on the phone (no adb needed). */
object DebugLog {
    @Volatile private var file: File? = null

    fun init(ctx: Context) { file = File(ctx.filesDir, "debug.log") }

    fun clear() { runCatching { file?.delete() } }

    @Synchronized
    fun log(msg: String) {
        val f = file ?: return
        runCatching {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            f.appendText("$t $msg\n")
        }
    }

    fun tail(ctx: Context, lines: Int): String {
        val f = File(ctx.filesDir, "debug.log")
        return if (f.exists()) f.readLines().takeLast(lines).joinToString("\n") else "(ไม่มี)"
    }
}
