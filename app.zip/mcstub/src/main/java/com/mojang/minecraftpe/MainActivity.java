package com.mojang.minecraftpe;

public class MainActivity extends android.app.NativeActivity {
}
